"""Generate the LaTeX tables and figure data of Section 7 from results.json."""
import json, math, os

R = json.load(open("../solver/results.json"))
OUT = "gen"
os.makedirs(OUT, exist_ok=True)


EXPECT_DAT = [f"{p}_{t}.dat" for p in ("loss","rely")
              for t in ("ex1_n1","ex1_n5","ex1_n20","ex1_n50","ex2_n1","ex2_n5")]
EXPECT_TAB = ["tab_dim.tex","tab_ex2.tex","tab_abl.tex","tab_ref.tex","tab_seed.tex"]


def w(name, s):
    open(os.path.join(OUT, name), "w").write(s)
    print("wrote", name)


def f(x, k=3):
    return f"{x:.{k}e}".replace("e-0", "e-").replace("e+0", "e+")


def sci(x, k=2):
    """LaTeX scientific notation"""
    if x == 0:
        return "0"
    e = int(math.floor(math.log10(abs(x))))
    m = x / 10 ** e
    return f"${m:.{k}f}\\cdot 10^{{{e}}}$"


def pc(x, k=2):
    v = 100 * x
    if v < 0.05:
        return f"{v:.3f}\\,\\%"
    return f"{v:.{k}f}\\,\\%"


def row_common(r):
    return (sci(r["loss"]), pc(r["relY0"]))


for _n in EXPECT_DAT + ["scatter.dat"]:
    p = os.path.join(OUT, _n)
    if not os.path.exists(p):
        open(p, "w").write("0 1\n")
for _n in EXPECT_TAB:
    p = os.path.join(OUT, _n)
    if not os.path.exists(p):
        open(p, "w").write("\\\\\n")

# ---------------------------------------------------------------- Table 1
lines = []
for tag in ["ex1_n1", "ex1_n5", "ex1_n20", "ex1_n50"]:
    if tag not in R:
        continue
    r = R[tag]
    gap = abs(r["cost"] - r["Jstar"]) / abs(r["Jstar"])
    lines.append(
        f"{r['n']} & {r['d']} & {sci(r['loss'])} & {pc(r['relY0'])} & "
        f"{r['cost']:.4f} & {r['Jstar']:.4f} & {pc(gap)} & {r['wall']:.0f} \\\\")
w("tab_dim.tex", "\n".join(lines) + "\n")

# ---------------------------------------------------------------- Table 2
lines = []
for tag in ["ex2_n1", "ex2_n5"]:
    if tag not in R:
        continue
    r = R[tag]
    lines.append(f"{r['n']} & {r['d']} & {r['iters']} & {sci(r['loss'])} & "
                 f"{pc(r['relY0'])} & {r['absY0err']:.4f} & {r['wall']:.0f} \\\\")
w("tab_ex2.tex", "\n".join(lines) + "\n")

# ---------------------------------------------------------------- Table 3 (ablations)
lab = {"": "full scheme", "nojump": "$\\Gamma^\\phi\\equiv0$",
       "nomean": "no measure input"}
lines = []
for fam, base in [("Example 1", "ex1_n5"), ("Example 2", "ex2_n5")]:
    for suf in ["", "_nojump", "_nomean"]:
        tag = base + suf
        if tag not in R:
            continue
        r = R[tag]
        name = lab[suf.strip("_")]
        lines.append(f"{fam} & {name} & {sci(r['loss'])} & {pc(r['relY0'])} \\\\")
    lines.append("\\addlinespace")
w("tab_abl.tex", "\n".join(lines) + "\n")

# ---------------------------------------------------------------- Table 4 (time steps)
lines = []
for tag in ["ex1_n5_N10", "ex1_n5_N20", "ex1_n5", "ex1_n5_N80"]:
    if tag not in R:
        continue
    r = R[tag]
    gap = abs(r["cost"] - r["Jstar"]) / abs(r["Jstar"])
    lines.append(f"{r['N']} & {r['M']*0+r['N']and r['N']} & {sci(r['loss'])} & "
                 f"{pc(r['relY0'])} & {pc(gap)} & {r['wall']:.0f} \\\\")
lines = [l.replace(f" & {R['ex1_n5']['N']} & ", " & ") for l in lines]  # tidy
w("tab_ref.tex", "\n".join(lines) + "\n")

# proper version
lines = []
for tag in ["ex1_n5_N10", "ex1_n5_N20", "ex1_n5", "ex1_n5_N80"]:
    if tag not in R:
        continue
    r = R[tag]
    gap = abs(r["cost"] - r["Jstar"]) / abs(r["Jstar"])
    lines.append(f"{r['N']} & {1.0/r['N']:.4f} & {sci(r['loss'])} & "
                 f"{pc(r['relY0'])} & {pc(gap)} & {r['wall']:.0f} \\\\")
w("tab_ref.tex", "\n".join(lines) + "\n")

# ---------------------------------------------------------------- Table 5 (seeds)
lines = []
for tag in ["ex1_n5", "ex1_n5_seed11", "ex1_n5_seed12"]:
    if tag not in R:
        continue
    r = R[tag]
    lines.append(f"{r['seed']} & {sci(r['loss'])} & {pc(r['relY0'])} & "
                 f"{r['cost']:.4f} \\\\")
w("tab_seed.tex", "\n".join(lines) + "\n")

# ---------------------------------------------------------------- Figures
def coords(tag, idx):
    r = R[tag]
    pts = [(h[0], h[idx]) for h in r["hist"] if h[idx] > 0]
    return "\n".join(f"{a} {b:.6g}" for a, b in pts)


for tag in ["ex1_n1", "ex1_n5", "ex1_n20", "ex1_n50", "ex2_n1", "ex2_n5"]:
    if tag in R:
        w(f"loss_{tag}.dat", coords(tag, 1) + "\n")
        w(f"rely_{tag}.dat", coords(tag, 2) + "\n")

# scatter: |y0 - Y0*| vs sqrt(loss)
pts = []
for tag, r in sorted(R.items()):
    if r["loss"] > 0:
        pts.append((math.sqrt(r["loss"]), r["absY0err"] if "absY0err" in r else
                    (r["relY0"] * (sum(v * v for v in r["y0_exact"]) ** .5))))
w("scatter.dat", "\n".join(f"{a:.6g} {b:.6g}" for a, b in sorted(pts)) + "\n")

print("\nsummary")
for t, r in sorted(R.items()):
    print(f"{t:18s} loss={r['loss']:.3e} relY0={r['relY0']:.4%} "
          f"wall={r['wall']:.0f}s")
