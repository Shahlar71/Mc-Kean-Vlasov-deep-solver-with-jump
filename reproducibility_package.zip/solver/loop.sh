#!/bin/bash
cd /home/claude/mvj
for tag in ex1_n50 ex2_n1 ex2_n5 ex1_n5_nojump ex2_n5_nojump \
           ex1_n5_nomean ex2_n5_nomean ex1_n5_N10 ex1_n5_N20 ex1_n5_N80 \
           ex1_n5_seed11 ex1_n5_seed12; do
  echo "=== START $tag $(date +%T)"
  python3 -u run_one.py $tag
  echo "=== END $tag rc=$? $(date +%T)"
done
echo "ALL DONE"
