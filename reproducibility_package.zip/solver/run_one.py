"""Run ONE experiment (fresh process) and append it to results.json."""
import json, os, sys, time
import numpy as np
from jax import random
import example1, example2, core

CONFIG = {
    # tag                 builder      kwargs
    "ex1_n1":        ("ex1", 1,  dict()),
    "ex1_n5":        ("ex1", 5,  dict()),
    "ex1_n20":       ("ex1", 20, dict()),
    "ex1_n50":       ("ex1", 50, dict()),
    "ex2_n1":        ("ex2", 1,  dict(iters=12000, lr1=3e-4)),
    "ex2_n5":        ("ex2", 5,  dict(iters=12000, lr1=3e-4)),
    "ex1_n5_nojump": ("ex1", 5,  dict(freeze=True)),
    "ex2_n5_nojump": ("ex2", 5,  dict(freeze=True, iters=12000, lr1=3e-4)),
    "ex1_n5_nomean": ("ex1", 5,  dict(nomean=True)),
    "ex2_n5_nomean": ("ex2", 5,  dict(nomean=True, iters=12000, lr1=3e-4)),
    "ex1_n5_N10":    ("ex1", 5,  dict(N=10)),
    "ex1_n5_N20":    ("ex1", 5,  dict(N=20)),
    "ex1_n5_N80":    ("ex1", 5,  dict(N=80)),
    "ex1_n5_seed11": ("ex1", 5,  dict(seed=11)),
    "ex1_n5_seed12": ("ex1", 5,  dict(seed=12)),
}


def main(tag):
    res = json.load(open("results.json")) if os.path.exists("results.json") else {}
    if tag in res:
        print(f"### {tag}: already done", flush=True); return
    fam, n, kw = CONFIG[tag]
    seed = kw.get("seed", 7); N = kw.get("N", 40); M = kw.get("M", 256)
    iters = kw.get("iters", 4000)
    lr0 = kw.get("lr0", 8e-3); lr1 = kw.get("lr1", 1e-4)
    p = (example1.build(n) if fam == "ex1" else example2.build(n))
    p.freeze_gamma = kw.get("freeze", False)
    p.no_mean_input = kw.get("nomean", False)

    t0 = time.time()
    ck = f"ckpt_{tag}.pkl"
    params, hist = core.train(p, random.PRNGKey(seed), N=N, M=M, iters=iters,
                              lr0=lr0, lr1=lr1, verbose=1000, ckpt=ck)
    wall = time.time() - t0
    loss, lse, cost, cse = core.evaluate(p, params, random.PRNGKey(1234),
                                         N=N, M=4096)
    y0 = np.array(params["y0"]); ye = np.asarray(p.Y0_exact)
    rec = dict(tag=tag, family=fam, n=p.n, d=p.d, N=N, M=M, iters=iters,
               seed=seed, lr0=lr0, lr1=lr1, freeze_gamma=p.freeze_gamma,
               no_mean_input=p.no_mean_input, wall=wall,
               loss=loss, loss_se=lse, cost=cost, cost_se=cse,
               Jstar=(float(p.Jstar) if p.Jstar is not None else None),
               relY0=float(np.linalg.norm(y0 - ye) / np.linalg.norm(ye)),
               absY0err=float(np.linalg.norm(y0 - ye)),
               y0=y0.tolist(), y0_exact=ye.tolist(),
               hist=[(int(i), float(l),
                      float(np.linalg.norm(np.array(y) - ye) / np.linalg.norm(ye)))
                     for i, l, y in hist])
    # re-read in case another process wrote meanwhile
    res = json.load(open("results.json")) if os.path.exists("results.json") else {}
    res[tag] = rec
    json.dump(res, open("results.json", "w"), indent=1)
    if os.path.exists(ck):
        os.remove(ck)
    print(f"### {tag}: loss={loss:.3e} relY0={rec['relY0']:.3%} "
          f"cost={cost:.4f} J*={rec['Jstar']} wall={wall:.0f}s", flush=True)


if __name__ == "__main__":
    main(sys.argv[1])
