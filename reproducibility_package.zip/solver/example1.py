"""
Example 1 -- linear-quadratic McKean-Vlasov control with jumps in dimension n.

  dX = (A X + Abar E[X] + B u) dt + Sig dW + int_Th th*c Ntilde(dth,dt)
  J  = E[ int_0^T .5 X'QX + .5 E[X]'Qbar E[X] + .5 u'Ru dt
          + .5 X_T'GT X_T + .5 E[X_T]'GTbar E[X_T] ]

Exact solution (see the paper):
  uhat = -R^{-1}B'Y,   Y_t = P_t (X_t - E X_t) + Pi_t E X_t,   Y_0 = Pi_0 x0
  P: Riccati(A,B,R,Q,GT),   Pi: Riccati(A+Abar,B,R,Q+Qbar,GT+GTbar)
  J* = .5 x0'Pi_0 x0 + .5 int_0^T [ tr(Sig'P Sig) + lam*E_F[th^2] c'P c ] dt
"""
import numpy as np
import jax.numpy as jnp
from core import Problem


def riccati(A, B, R, Q, GT, T, Nr=4000):
    """Backward solve of  P' + PA + A'P - P B R^{-1} B' P + Q = 0, P(T)=GT."""
    Rinv = np.linalg.inv(R)
    S = B @ Rinv @ B.T
    h = T / Nr

    def f(P):                                   # dP/ds with s = T - t
        return P @ A + A.T @ P - P @ S @ P + Q

    P = GT.copy()
    traj = [P.copy()]
    for _ in range(Nr):
        k1 = f(P); k2 = f(P + .5 * h * k1); k3 = f(P + .5 * h * k2); k4 = f(P + h * k3)
        P = P + h / 6 * (k1 + 2 * k2 + 2 * k3 + k4)
        traj.append(P.copy())
    traj = np.array(traj)[::-1]                 # traj[j] = P at t = j*h
    return P, traj                              # P = P(0)


def build(n, d=None, T=1.0, seed=0):
    rng = np.random.default_rng(seed)
    if d is None:
        d = 1 if n == 1 else min(n, 4)
    one = np.ones((n, n)) / n

    E = rng.standard_normal((n, n)) / np.sqrt(n)
    V = rng.standard_normal((n, 3)) / np.sqrt(n)
    U = rng.standard_normal((n, 2)) / np.sqrt(n)

    A = -0.5 * np.eye(n) + 0.5 * one + 0.4 * E
    Abar = 0.3 * one + 0.2 * (E - E.T)
    B = np.eye(n)
    R = np.eye(n) + 0.3 * np.diag(np.abs(rng.standard_normal(n)))
    Q = np.eye(n) + V @ V.T
    Qbar = 0.5 * one + U @ U.T
    GT = np.eye(n) + 0.5 * V @ V.T
    GTbar = 0.5 * one
    Sig = 0.3 * rng.standard_normal((n, d)) / np.sqrt(d)
    c = 0.5 * (1.0 + 0.5 * np.sin(np.arange(n))) / np.sqrt(n)

    lam, mJ, dJ = 1.0, 0.2, 0.3
    x0 = 1.0 + 0.5 * np.sin(np.arange(n))

    P0, Ptr = riccati(A, B, R, Q, GT, T)
    Pi0, Pitr = riccati(A + Abar, B, R, Q + Qbar, GT + GTbar, T)

    Y0 = Pi0 @ x0
    m2 = lam * (mJ ** 2 + dJ ** 2)              # int th^2 nu(dth)
    h = T / (len(Ptr) - 1)
    integ = 0.0
    for j in range(len(Ptr)):
        w = h * (0.5 if j in (0, len(Ptr) - 1) else 1.0)
        integ += w * (np.trace(Sig.T @ Ptr[j] @ Sig) + m2 * c @ Ptr[j] @ c)
    Jstar = 0.5 * x0 @ Pi0 @ x0 + 0.5 * integ

    p = Problem()
    p.name = f"LQ-MV-jump n={n}"
    p.n, p.k, p.d, p.T = n, n, d, T
    p.lam, p.mJ, p.dJ = lam, mJ, dJ
    p.x0 = jnp.array(x0, dtype=jnp.float32)
    p.Y0_exact, p.Jstar = Y0, Jstar

    jA, jAb, jB, jR = map(lambda M: jnp.array(M, dtype=jnp.float32), (A, Abar, B, R))
    jQ, jQb, jGT, jGTb = map(lambda M: jnp.array(M, dtype=jnp.float32),
                             (Q, Qbar, GT, GTbar))
    jSig = jnp.array(Sig, dtype=jnp.float32)
    jc = jnp.array(c, dtype=jnp.float32)
    KB = jnp.array(B @ np.linalg.inv(R).T, dtype=jnp.float32)   # u_row = -Y_row @ KB

    p.uhat = lambda t, X, xb, Y, Z, Gth, Gi: -Y @ KB
    p.b = lambda t, X, xb, u: X @ jA.T + xb @ jAb.T + u @ jB.T
    p.sigma = lambda t, X, xb, u: jnp.broadcast_to(jSig, (X.shape[0], n, d))
    p.gam = lambda t, X, xb, u, th: th[:, :, None] * jc[None, None, :]
    p.Fdrift = lambda t, X, xb, u, Y, yb, Z, Gi, Gth: (
        Y @ jA + yb @ jAb + X @ jQ + xb @ jQb)
    p.G = lambda X, xb: X @ jGT.T + xb @ jGTb.T
    p.running = lambda t, X, xb, u: (
        0.5 * jnp.sum((X @ jQ) * X, 1) + 0.5 * jnp.sum((u @ jR) * u, 1)
        + 0.5 * jnp.sum((xb @ jQb) * xb))
    p.terminal = lambda X, xb: (0.5 * jnp.sum((X @ jGT) * X, 1)
                                + 0.5 * jnp.sum((xb @ jGTb) * xb))
    return p
