"""
Deep solver for fully coupled McKean-Vlasov FBSDEs with jumps.

The mini-batch IS the interacting particle system: the law P_{X_t} is replaced
by the empirical measure of the M particles carried in the batch.

Notation (paper):
  dX = b(t,X,mu,u) dt + sigma(t,X,mu,u) dW + int gamma(t,X_,mu,u,th) Ntilde(dth,dt)
 -dY = F(t,X,mu,u,Y,Z,Gamma) dt - Z dW - int Gamma(th) Ntilde(dth,dt)
  Y_T = G(X_T, mu_T)
with u = uhat(t,X,mu,Y,Z,Gamma) the minimiser of the Hamiltonian.
"""
import functools, os, pickle
import jax
import jax.numpy as jnp
from jax import random
import numpy as np

jax.config.update("jax_enable_x64", False)


# ----------------------------------------------------------------------
# MLP
# ----------------------------------------------------------------------
def init_mlp(key, sizes):
    params = []
    for din, dout in zip(sizes[:-1], sizes[1:]):
        key, k = random.split(key)
        W = random.normal(k, (din, dout)) * jnp.sqrt(2.0 / din)
        b = jnp.zeros((dout,))
        params.append((W, b))
    return params


def mlp(params, x):
    for (W, b) in params[:-1]:
        x = jnp.tanh(x @ W + b)
    W, b = params[-1]
    return x @ W + b


# ----------------------------------------------------------------------
# Adam
# ----------------------------------------------------------------------
def adam_init(params):
    return (jax.tree_util.tree_map(jnp.zeros_like, params),
            jax.tree_util.tree_map(jnp.zeros_like, params), 0)


def adam_step(params, grads, state, lr, b1=0.9, b2=0.999, eps=1e-8):
    m, v, t = state
    t = t + 1
    m = jax.tree_util.tree_map(lambda m_, g: b1 * m_ + (1 - b1) * g, m, grads)
    v = jax.tree_util.tree_map(lambda v_, g: b2 * v_ + (1 - b2) * g * g, v, grads)
    mh = jax.tree_util.tree_map(lambda m_: m_ / (1 - b1 ** t), m)
    vh = jax.tree_util.tree_map(lambda v_: v_ / (1 - b2 ** t), v)
    params = jax.tree_util.tree_map(
        lambda p, m_, v_: p - lr * m_ / (jnp.sqrt(v_) + eps), params, mh, vh)
    return params, (m, v, t)


# ----------------------------------------------------------------------
# Gauss-Hermite quadrature for nu(dth) = lam * N(mJ, dJ^2)
# ----------------------------------------------------------------------
def gh_nodes(mJ, dJ, nq):
    x, w = np.polynomial.hermite_e.hermegauss(nq)     # weight exp(-x^2/2)
    w = w / np.sqrt(2 * np.pi)                        # normalised to prob. measure
    return jnp.array(mJ + dJ * x, dtype=jnp.float32), jnp.array(w, dtype=jnp.float32)


# ----------------------------------------------------------------------
# Problem container
# ----------------------------------------------------------------------
class Problem:
    """
    Fields required:
      n, k, d           state / control / Brownian dimensions
      T, x0
      lam, mJ, dJ       finite-activity Merton-type mark intensity & law
      b, sigma, gam     forward coefficients  (batched, see examples)
      uhat              Hamiltonian minimiser
      Fdrift            backward driver  = d_x H + E~[d_mu H]
      G                 terminal condition of the adjoint
      running           running cost ell (for the cost functional)
      terminal          terminal cost h
    """
    pass


# ----------------------------------------------------------------------
# One forward pass of the discretised particle system
# ----------------------------------------------------------------------
def simulate(params, prob, noise, N, train=True, want_cost=False):
    """noise = (dW, marks, mask) with
         dW    (N, M, d)
         marks (N, M, Kmax)
         mask  (N, M, Kmax)   1 if that jump occurred
    """
    y0, pZ, pG = params["y0"], params["Z"], params["Gamma"]
    dW, marks, mask = noise
    M = dW.shape[1]
    dt = prob.T / N
    sq = jnp.sqrt(dt)

    th_q, w_q = prob.quad                      # (nq,), (nq,)
    nq = th_q.shape[0]

    X = jnp.broadcast_to(prob.x0, (M, prob.n))
    Y = jnp.broadcast_to(y0, (M, prob.n))
    cost = jnp.zeros(())

    no_mean = getattr(prob, "no_mean_input", False)

    def _mu_in(xbar):
        """the distributional input of the networks (zeroed in the ablation)"""
        return jnp.zeros_like(xbar) if no_mean else xbar

    def Zfun(t, X, xbar):
        inp = jnp.concatenate(
            [jnp.full((M, 1), t), X,
             jnp.broadcast_to(_mu_in(xbar), (M, prob.n))], axis=1)
        return mlp(pZ, inp).reshape(M, prob.n, prob.d)

    freeze = getattr(prob, "freeze_gamma", False)

    def Gfun(t, X, xbar, th):
        """th: (M,J) marks -> (M,J,n)"""
        J = th.shape[1]
        if freeze:
            return jnp.zeros((M, J, prob.n))
        base = jnp.concatenate(
            [jnp.full((M, 1), t), X,
             jnp.broadcast_to(_mu_in(xbar), (M, prob.n))], axis=1)
        base = jnp.repeat(base[:, None, :], J, axis=1)          # (M,J,1+2n)
        inp = jnp.concatenate([base, th[:, :, None]], axis=2)
        return mlp(pG, inp.reshape(M * J, -1)).reshape(M, J, prob.n)

    def body(carry, inp):
        X, Y, cost = carry
        t, dWi, thr, mki = inp
        xbar = jnp.mean(X, axis=0)
        ybar = jnp.mean(Y, axis=0)

        Z = Zfun(t, X, xbar)                                   # (M,n,d)
        thq = jnp.broadcast_to(th_q, (M, nq))
        Gq = Gfun(t, X, xbar, thq)                             # (M,nq,n)
        # int Gamma nu(dth) and int th*Gamma nu(dth)
        Gint = prob.lam * jnp.einsum("q,mqn->mn", w_q, Gq)
        Gthint = prob.lam * jnp.einsum("q,q,mqn->mn", w_q, th_q, Gq)

        u = prob.uhat(t, X, xbar, Y, Z, Gthint, Gint)          # (M,k)

        bb = prob.b(t, X, xbar, u)                             # (M,n)
        ss = prob.sigma(t, X, xbar, u)                         # (M,n,d)
        drv = prob.Fdrift(t, X, xbar, u, Y, ybar, Z, Gint, Gthint)   # (M,n)

        # ---- jump increments -------------------------------------------
        gj = prob.gam(t, X, xbar, u, thr)                      # (M,Kmax,n)
        gq = prob.gam(t, X, xbar, u, thq)                      # (M,nq,n)
        gcomp = prob.lam * jnp.einsum("q,mqn->mn", w_q, gq)
        dJX = jnp.sum(gj * mki[:, :, None], axis=1) - dt * gcomp

        Gr = Gfun(t, X, xbar, thr)                             # (M,Kmax,n)
        dJY = jnp.sum(Gr * mki[:, :, None], axis=1) - dt * Gint

        cost = cost + dt * jnp.mean(prob.running(t, X, xbar, u))

        Xn = X + bb * dt + jnp.einsum("mnd,md->mn", ss, dWi) * sq + dJX
        Yn = Y - drv * dt + jnp.einsum("mnd,md->mn", Z, dWi) * sq + dJY
        return (Xn, Yn, cost), None

    ts = jnp.arange(N, dtype=jnp.float32) * dt
    (X, Y, cost), _ = jax.lax.scan(body, (X, Y, cost), (ts, dW, marks, mask))

    xbar = jnp.mean(X, axis=0)
    resid = Y - prob.G(X, xbar)
    loss = jnp.mean(jnp.sum(resid ** 2, axis=1))
    cost = cost + jnp.mean(prob.terminal(X, xbar))
    return loss, (X, Y, cost)


def make_noise(key, prob, N, M, Kmax):
    dt = prob.T / N
    k1, k2, k3 = random.split(key, 3)
    dW = random.normal(k1, (N, M, prob.d))
    marks = prob.mJ + prob.dJ * random.normal(k2, (N, M, Kmax))
    cnt = random.poisson(k3, prob.lam * dt, (N, M))
    mask = (jnp.arange(Kmax)[None, None, :] < cnt[:, :, None]).astype(jnp.float32)
    return dW, marks, mask


# ----------------------------------------------------------------------
# Training loop
# ----------------------------------------------------------------------
def train(prob, key, N=40, M=256, Kmax=3, nq=5, iters=1500,
          lr0=1e-2, lr1=1e-3, width=None, verbose=100, hist_every=25,
          ckpt=None, ckpt_every=200):
    prob.quad = gh_nodes(prob.mJ, prob.dJ, nq)
    if width is None:
        width = prob.n + 20
    k1, k2, k3 = random.split(key, 3)
    params = {
        "y0": jnp.zeros((prob.n,)),
        "Z": init_mlp(k1, [1 + 2 * prob.n, width, width, prob.n * prob.d]),
        "Gamma": init_mlp(k2, [2 + 2 * prob.n, width, width, prob.n]),
    }
    st = adam_init(params)
    hist = []
    start = 0

    to_np = lambda tr: jax.tree_util.tree_map(np.asarray, tr)
    to_jx = lambda tr: jax.tree_util.tree_map(jnp.asarray, tr)

    if ckpt is not None and os.path.exists(ckpt):
        d = pickle.load(open(ckpt, "rb"))
        params = to_jx(d["params"]); st = to_jx(d["st"])
        start = d["it"]; hist = d["hist"]; k3 = jnp.asarray(d["key"])
        print(f"  [resumed from {ckpt} at iteration {start}]", flush=True)

    @jax.jit
    def step(params, st, noise, lr):
        loss, g = jax.value_and_grad(lambda p: simulate(p, prob, noise, N)[0])(params)
        params, st = adam_step(params, g, st, lr)
        return params, st, loss

    for it in range(start, iters):
        k3, kk = random.split(k3)
        noise = make_noise(kk, prob, N, M, Kmax)
        lr = lr0 * (lr1 / lr0) ** (it / max(iters - 1, 1))
        params, st, loss = step(params, st, noise, lr)
        if it % hist_every == 0 or it == iters - 1:
            hist.append((it, float(loss), np.array(params["y0"])))
        if verbose and (it % verbose == 0 or it == iters - 1):
            print(f"  it {it:5d}  loss {float(loss):.4e}  "
                  f"y0[0] {float(params['y0'][0]): .6f}", flush=True)
        if ckpt is not None and (it % ckpt_every == 0 or it == iters - 1):
            tmp = ckpt + ".tmp"
            pickle.dump(dict(params=to_np(params), st=to_np(st), it=it + 1,
                             hist=hist, key=np.asarray(k3)),
                        open(tmp, "wb"))
            os.replace(tmp, ckpt)
    return params, hist


def evaluate(prob, params, key, N=40, M=4096, Kmax=3, chunk=512):
    """Monte-Carlo evaluation of the terminal loss and of the realised cost."""
    losses, costs = [], []
    nch = M // chunk
    for c in range(nch):
        key, kk = random.split(key)
        noise = make_noise(kk, prob, N, chunk, Kmax)
        l, (X, Y, cost) = simulate(params, prob, noise, N, want_cost=True)
        losses.append(float(l)); costs.append(float(cost))
    return float(np.mean(losses)), float(np.std(losses) / np.sqrt(nch)), \
           float(np.mean(costs)), float(np.std(costs) / np.sqrt(nch))
