"""
Example 2 -- LQ McKean-Vlasov control with CONTROL-DEPENDENT diffusion and jump
coefficients.  Here the minimiser of the Hamiltonian genuinely depends on Z and
on Gamma:

  dX = (A X + Abar E[X] + B u) dt + (s0 + D u) dW
       + int_Th (g0 + F u) th Ntilde(dth,dt)

  uhat = -Rcal^{-1}( B'Y + D'Z + F' int th Gamma(th) nu(dth) )   (implicit form)
       = -R^{-1}( B'Y + D'Z + F' int th Gamma nu(dth) )          (form used by the solver)

Closed form:
  Y_t = P_t (X_t - E X_t) + Pi_t E X_t + phi_t,     Y_0 = Pi_0 x0 + phi_0
  Rcal_t = R + D'P_t D + lam2 F'P_t F,   rho_t = D'P_t s0 + lam2 F'P_t g0
  P'  + PA + A'P - P B Rcal^{-1} B'P + Q = 0,                P_T = GT
  Pi' + Pi(A+Abar) + (A+Abar)'Pi - Pi B Rcal^{-1}B'Pi + Q+Qbar = 0, Pi_T = GT+GTbar
  phi'= [Pi B Rcal^{-1}B' - (A+Abar)'] phi + Pi B Rcal^{-1} rho,  phi_T = 0
"""
import numpy as np
import jax.numpy as jnp
from core import Problem


def solve_riccati_system(A, Abar, B, R, Q, Qbar, GT, GTbar, D, F, s0, g0,
                         lam2, T, Nr=4000):
    n = A.shape[0]
    h = T / Nr

    def Rcal(P):
        return R + D.T @ P @ D + lam2 * F.T @ P @ F

    def fP(P):
        Ri = np.linalg.inv(Rcal(P))
        return P @ A + A.T @ P - P @ B @ Ri @ B.T @ P + Q

    # --- P backward ---
    P = GT.copy(); Ptr = [P.copy()]
    for _ in range(Nr):
        k1 = fP(P); k2 = fP(P + .5*h*k1); k3 = fP(P + .5*h*k2); k4 = fP(P + h*k3)
        P = P + h/6*(k1 + 2*k2 + 2*k3 + k4); Ptr.append(P.copy())
    Ptr = np.array(Ptr)[::-1]                      # index j -> t = j*h

    AA = A + Abar; QQ = Q + Qbar

    def fPi(Pi, P):
        Ri = np.linalg.inv(Rcal(P))
        return Pi @ AA + AA.T @ Pi - Pi @ B @ Ri @ B.T @ Pi + QQ

    Pi = (GT + GTbar).copy(); Pitr = [Pi.copy()]
    for j in range(Nr):                            # backward: s = T-t
        Pb = Ptr[Nr - j]; Pm = Ptr[max(Nr - j - 1, 0)]
        Ph = 0.5 * (Pb + Pm)
        k1 = fPi(Pi, Pb); k2 = fPi(Pi + .5*h*k1, Ph)
        k3 = fPi(Pi + .5*h*k2, Ph); k4 = fPi(Pi + h*k3, Pm)
        Pi = Pi + h/6*(k1 + 2*k2 + 2*k3 + k4); Pitr.append(Pi.copy())
    Pitr = np.array(Pitr)[::-1]

    # --- phi backward ---
    def fphi(phi, P, Pi):
        Ri = np.linalg.inv(Rcal(P))
        rho = D.T @ P @ s0 + lam2 * F.T @ P @ g0
        # returns -d(phi)/dt, i.e. d(phi)/ds with s = T - t
        return -((Pi @ B @ Ri @ B.T - AA.T) @ phi + Pi @ B @ Ri @ rho)

    phi = np.zeros(n); phitr = [phi.copy()]
    for j in range(Nr):
        Pb, Pm = Ptr[Nr - j], Ptr[max(Nr - j - 1, 0)]
        Qb, Qm = Pitr[Nr - j], Pitr[max(Nr - j - 1, 0)]
        Ph, Qh = .5*(Pb + Pm), .5*(Qb + Qm)
        k1 = fphi(phi, Pb, Qb); k2 = fphi(phi + .5*h*k1, Ph, Qh)
        k3 = fphi(phi + .5*h*k2, Ph, Qh); k4 = fphi(phi + h*k3, Pm, Qm)
        phi = phi + h/6*(k1 + 2*k2 + 2*k3 + k4); phitr.append(phi.copy())
    phitr = np.array(phitr)[::-1]
    return Ptr, Pitr, phitr


def build(n, T=1.0, seed=3):
    rng = np.random.default_rng(seed)
    d = 1
    one = np.ones((n, n)) / n
    E = rng.standard_normal((n, n)) / np.sqrt(n)
    V = rng.standard_normal((n, 2)) / np.sqrt(n)

    A = -0.4 * np.eye(n) + 0.3 * one + 0.3 * E
    Abar = 0.25 * one
    B = np.eye(n)
    R = np.eye(n)
    Q = np.eye(n) + V @ V.T
    Qbar = 0.4 * one
    GT = 0.8 * np.eye(n)
    GTbar = 0.4 * one
    D = 0.25 * np.eye(n)
    F = 0.20 * np.eye(n)
    s0 = 0.30 * (1.0 + 0.3 * np.cos(np.arange(n))) / np.sqrt(n) * np.sqrt(n)
    g0 = 0.40 * (1.0 + 0.3 * np.sin(np.arange(n))) / np.sqrt(n)

    lam, mJ, dJ = 1.0, 0.2, 0.3
    lam2 = lam * (mJ ** 2 + dJ ** 2)
    x0 = 1.0 + 0.4 * np.cos(np.arange(n))

    Ptr, Pitr, phitr = solve_riccati_system(A, Abar, B, R, Q, Qbar, GT, GTbar,
                                            D, F, s0, g0, lam2, T)
    Y0 = Pitr[0] @ x0 + phitr[0]

    p = Problem()
    p.name = f"LQ-MV-jump, control-dependent noise, n={n}"
    p.n, p.k, p.d, p.T = n, n, d, T
    p.lam, p.mJ, p.dJ = lam, mJ, dJ
    p.x0 = jnp.array(x0, dtype=jnp.float32)
    p.Y0_exact = Y0
    p.Jstar = None
    p.raw = dict(A=A, Abar=Abar, B=B, R=R, Q=Q, Qbar=Qbar, GT=GT, GTbar=GTbar,
                 D=D, F=F, s0=s0, g0=g0, lam=lam, mJ=mJ, dJ=dJ, lam2=lam2,
                 x0=x0, T=T, Ptr=Ptr, Pitr=Pitr, phitr=phitr)

    f32 = lambda M: jnp.array(M, dtype=jnp.float32)
    jA, jAb, jB, jQ, jQb, jGT, jGTb = map(f32, (A, Abar, B, Q, Qbar, GT, GTbar))
    jD, jF, js0, jg0, jR = map(f32, (D, F, s0, g0, R))
    RinvT = f32(np.linalg.inv(R).T)

    def uhat(t, X, xb, Y, Z, Gth, Gi):
        return -(Y @ jB + Z[:, :, 0] @ jD + Gth @ jF) @ RinvT

    p.uhat = uhat
    p.b = lambda t, X, xb, u: X @ jA.T + xb @ jAb.T + u @ jB.T
    p.sigma = lambda t, X, xb, u: (js0[None, :] + u @ jD.T)[:, :, None]
    p.gam = lambda t, X, xb, u, th: (
        (jg0[None, :] + u @ jF.T)[:, None, :] * th[:, :, None])
    p.Fdrift = lambda t, X, xb, u, Y, yb, Z, Gi, Gth: (
        Y @ jA + yb @ jAb + X @ jQ + xb @ jQb)
    p.G = lambda X, xb: X @ jGT.T + xb @ jGTb.T
    p.running = lambda t, X, xb, u: (0.5 * jnp.sum((X @ jQ) * X, 1)
                                     + 0.5 * jnp.sum((u @ jR) * u, 1)
                                     + 0.5 * jnp.sum((xb @ jQb) * xb))
    p.terminal = lambda X, xb: (0.5 * jnp.sum((X @ jGT) * X, 1)
                                + 0.5 * jnp.sum((xb @ jGTb) * xb))
    return p
