# Reproducibility package

**A deep solver and an a posteriori error estimate for McKean--Vlasov control
problems with jumps**
S. Meherrem, T. Guluzada, E. Çetin

This archive reproduces every number, table and figure of Section 7 and the two
independent checks described in Section 7.2.

--------------------------------------------------------------------------
## Requirements

    python >= 3.11
    jax == 0.11.2      (CPU build is sufficient; all reported runs used one CPU core)
    numpy >= 2.0
    scipy >= 1.13

    pip install "jax[cpu]" numpy scipy

No GPU is required. The full experiment suite takes roughly two hours on a
single CPU core.

--------------------------------------------------------------------------
## Contents

    solver/core.py          the deep solver: networks, jump-adapted Euler scheme,
                            Gauss-Hermite quadrature for the compensator, Adam
    solver/example1.py      Example 7.1 (additive noise) and its closed-form
                            solution (Proposition D.1): Riccati equations for
                            P and Pi, exact Y_0 and exact optimal value J*
    solver/example2.py      Example 7.2 (control-dependent diffusion and jump
                            size) and its closed-form solution
                            (Proposition D.2): P, Pi and the offset phi
    solver/run_one.py       runs one configuration and appends it to results.json
    solver/loop.sh          runs the fifteen configurations of Section 7 in turn
    solver/results.json     the stored output of those fifteen runs, including the
                            full loss and error histories used in Figure 1

    verification/verify_exact.py   checks the closed form of Example 7.1 against a
                                   Monte-Carlo evaluation of the closed-loop cost
    verification/verify_ex2.py     checks the closed form of Example 7.2 by
                                   measuring the terminal FBSDE residual
    verification/check_mono.py     checks identity (33) of Appendix B, on which
                                   Lemma 4.2 rests, by direct computation

    figures/make_tables.py  regenerates Tables 1-5 and the data of Figures 1-2
                            from results.json

--------------------------------------------------------------------------
## Reproducing the results

1. The two independent checks of Section 7.2 (a few minutes each):

       cd verification
       python3 verify_exact.py     # expect 1.23709 vs 1.23273 (n=1), 7.43875 vs 7.40735 (n=5)
       python3 verify_ex2.py       # expect residuals 3.3e-05 (n=1) and 3.2e-07 (n=5)
       python3 check_mono.py       # expect agreement to machine precision

2. Tables and figures, from the stored runs:

       cd figures
       python3 make_tables.py      # writes the LaTeX table bodies and the plot data

3. The fifteen runs themselves, from scratch:

       cd solver
       rm results.json             # otherwise completed runs are skipped
       ./loop.sh

   Each configuration is run in a fresh process and its result is appended to
   results.json, so the suite can be interrupted and restarted; completed
   configurations are skipped. Individual configurations can be run directly,

       python3 run_one.py ex1_n50

   the available names being ex1_n1, ex1_n5, ex1_n20, ex1_n50, ex2_n1, ex2_n5,
   ex1_n5_nojump, ex2_n5_nojump, ex1_n5_nomean, ex2_n5_nomean, ex1_n5_N10,
   ex1_n5_N20, ex1_n5_N80, ex1_n5_seed11, ex1_n5_seed12.

--------------------------------------------------------------------------
## Notes on exact reproducibility

All random numbers are drawn from seeded JAX PRNG keys, so a run repeats
bit-for-bit on the same JAX version and platform. Across JAX versions or
platforms the compiled kernels may differ slightly in floating-point order and
the numbers can move in the last reported digit; the seed study of Table 5
indicates the size of that variability, which is well below the accuracies
reported.

Computations are in single precision, which is the usual choice for this class
of solver. Setting `JAX_ENABLE_X64=1` reproduces the same numbers in double
precision at roughly twice the cost.
