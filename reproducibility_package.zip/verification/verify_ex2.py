"""Check the closed form of Example 2 by propagating the FBSDE forward with the
analytic (Y0, Z, Gamma) and measuring the terminal mismatch E|Y_T - G(X_T,muT)|^2."""
import numpy as np, example2

def check(n, N=400, M=60000, seed=5):
    p = example2.build(n); r = p.raw
    A,Ab,B,R,Q,Qb,GT,GTb = r['A'],r['Abar'],r['B'],r['R'],r['Q'],r['Qbar'],r['GT'],r['GTbar']
    D,F,s0,g0 = r['D'],r['F'],r['s0'],r['g0']
    lam,mJ,dJ,lam2,x0,T = r['lam'],r['mJ'],r['dJ'],r['lam2'],r['x0'],r['T']
    Ptr,Pitr,phitr = r['Ptr'],r['Pitr'],r['phitr']
    hR = T/(len(Ptr)-1); dt = T/N; g = np.random.default_rng(seed)
    X = np.tile(x0,(M,1)); Y = np.tile(Pitr[0]@x0 + phitr[0],(M,1))
    for i in range(N):
        t=i*dt; j=int(round(t/hR)); P,Pi,ph = Ptr[j],Pitr[j],phitr[j]
        Rc = R + D.T@P@D + lam2*F.T@P@F; Ri=np.linalg.inv(Rc)
        rho = D.T@P@s0 + lam2*F.T@P@g0
        u = -(Y@B + np.tile(rho,(M,1)))@Ri.T
        sig = s0[None,:] + u@D.T                  # (M,n)
        gjc = g0[None,:] + u@F.T                  # (M,n)
        Z  = sig@P.T
        # Gamma(th) = P (g0+Fu) th
        dW = g.standard_normal(M)*np.sqrt(dt)
        cnt = g.poisson(lam*dt,M); S=np.zeros(M)
        for kk in range(cnt.max() if cnt.max()>0 else 0):
            S += (cnt>kk)*(mJ+dJ*g.standard_normal(M))
        Scomp = S - dt*lam*mJ
        xb = X.mean(0)
        Xn = X + (X@A.T + xb@Ab.T + u@B.T)*dt + sig*dW[:,None] + gjc*Scomp[:,None]
        yb = Y.mean(0)
        drift = Y@A + yb@Ab + X@Q + xb@Qb
        Yn = Y - drift*dt + Z*dW[:,None] + (gjc@P.T)*Scomp[:,None]
        X,Y = Xn,Yn
    xb=X.mean(0)
    res = Y - (X@GT.T + xb@GTb.T)
    return np.mean(np.sum(res**2,1)), np.mean(np.sum((X@GT.T+xb@GTb.T)**2,1)), p.Y0_exact

for n in [1,5]:
    e,s,y0 = check(n)
    print(f"n={n}: E|Y_T-G|^2 = {e:.3e}   (scale E|G|^2 = {s:.3e})   ratio {e/s:.2e}")
    print(f"      Y0_exact[:4] = {np.round(y0[:4],6)}")
