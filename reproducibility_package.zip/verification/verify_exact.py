"""Independent Monte-Carlo check of the closed-form solution of Example 1."""
import numpy as np, example1

def mc_cost(n, seed=1, M=200000, N=200):
    p = example1.build(n)
    # rebuild raw matrices
    rng = np.random.default_rng(0); d = p.d
    one = np.ones((n,n))/n
    E = rng.standard_normal((n,n))/np.sqrt(n); V = rng.standard_normal((n,3))/np.sqrt(n)
    U = rng.standard_normal((n,2))/np.sqrt(n)
    A=-0.5*np.eye(n)+0.5*one+0.4*E; Abar=0.3*one+0.2*(E-E.T); B=np.eye(n)
    R=np.eye(n)+0.3*np.diag(np.abs(rng.standard_normal(n))); Q=np.eye(n)+V@V.T
    Qbar=0.5*one+U@U.T; GT=np.eye(n)+0.5*V@V.T; GTbar=0.5*one
    Sig=0.3*rng.standard_normal((n,d))/np.sqrt(d)
    c=0.5*(1.0+0.5*np.sin(np.arange(n)))/np.sqrt(n)
    lam,mJ,dJ=1.0,0.2,0.3; x0=1.0+0.5*np.sin(np.arange(n)); T=1.0
    _,Ptr  = example1.riccati(A,B,R,Q,GT,T)
    _,Pitr = example1.riccati(A+Abar,B,R,Q+Qbar,GT+GTbar,T)
    hR = T/(len(Ptr)-1)
    Rinv=np.linalg.inv(R); dt=T/N
    g=np.random.default_rng(seed)
    X=np.tile(x0,(M,1)); cost=0.0
    for i in range(N):
        t=i*dt; j=int(round(t/hR)); P=Ptr[j]; Pi=Pitr[j]
        xb=X.mean(0); dX=X-xb
        Y=dX@P.T + xb@Pi.T
        u=-Y@B@Rinv.T
        cost+= dt*( (0.5*np.sum((X@Q)*X,1)+0.5*np.sum((u@R)*u,1)).mean()
                    +0.5*xb@Qbar@xb )
        dW=g.standard_normal((M,d))*np.sqrt(dt)
        cnt=g.poisson(lam*dt,M)
        S=np.zeros(M)
        mx=cnt.max()
        for kk in range(mx):
            S += (cnt>kk)*(mJ+dJ*g.standard_normal(M))
        dJump=np.outer(S,c)-dt*lam*mJ*np.outer(np.ones(M),c)
        X = X + (X@A.T+xb@Abar.T+u@B.T)*dt + dW@Sig.T + dJump
    xb=X.mean(0)
    cost += (0.5*np.sum((X@GT)*X,1)).mean()+0.5*xb@GTbar@xb
    return cost, p.Jstar, p.Y0_exact

for n in [1,5]:
    c,js,y0=mc_cost(n)
    print(f"n={n}: MC cost {c:.5f}   analytic J* {js:.5f}   rel.diff {abs(c-js)/abs(js):.3%}")
    print(f"     Y0_exact[:3] = {np.round(y0[:3],5)}")
