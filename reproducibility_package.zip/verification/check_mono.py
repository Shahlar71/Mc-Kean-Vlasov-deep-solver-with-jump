"""Independent numerical check of Lemma 4.3 / identity (B.3) of the manuscript:
for the mean-field LQ class with jumps,
  E<A(Lambda)-A(Lambda'), hat Lambda> = -E[x^T Q x] - (E x)^T Qbar (E x) - E[Pi^T R^-1 Pi],
with Pi = B^T y + D^* z + F^* int theta r(theta) nu(dtheta), all hats being differences.
"""
import numpy as np
rng = np.random.default_rng(1)
n, k, d, M = 4, 3, 2, 400000          # state, control, Brownian dims; sample size
nodes = np.array([-1.3, 0.4, 2.1]); wts = np.array([0.5, 0.8, 0.3])   # discrete nu

A = rng.normal(size=(n, n)); Abar = rng.normal(size=(n, n))
B = rng.normal(size=(n, k))
Dm = rng.normal(size=(n, d, k))       # sigma = sigma0 + D u,  (D u)_{ij} = Dm[i,j,:] . u
Fm = rng.normal(size=(n, k))          # gamma = (gamma0 + F u) theta
Q = rng.normal(size=(n, n)); Q = Q @ Q.T + np.eye(n)
Qb = rng.normal(size=(n, n)); Qb = Qb @ Qb.T
R = rng.normal(size=(k, k)); R = R @ R.T + np.eye(k)
Rinv = np.linalg.inv(R)

def draw():
    return (rng.normal(size=(M, n)), rng.normal(size=(M, n)),
            rng.normal(size=(M, n, d)), rng.normal(size=(M, len(nodes), n)))

x, y, z, r = draw()
x2, y2, z2, r2 = draw()
hx, hy, hz, hr = x - x2, y - y2, z - z2, r - r2

lam2 = np.einsum('q,q->', wts, nodes**2)          # int theta^2 nu
def Pi(y_, z_, r_):
    t1 = y_ @ B                                    # B^T y
    t2 = np.einsum('ijk,mij->mk', Dm, z_)          # D^* z
    thr = np.einsum('q,mqi->mi', wts * nodes, r_)  # int theta r nu
    t3 = thr @ Fm                                  # F^* (.)
    return t1 + t2 + t3

hPi = Pi(hy, hz, hr)
uhat = -hPi @ Rinv.T                               # increment of the minimiser

# increments of the four maps (constants sigma0, gamma0 cancel)
hB   = hx @ A.T + hx.mean(0) @ Abar.T + uhat @ B.T
hSig = np.einsum('ijk,mk->mij', Dm, uhat)
hUps = np.einsum('ik,mk->mi', Fm, uhat)            # coefficient of theta
hF   = hy @ A + hx @ Q + hy.mean(0) @ Abar + hx.mean(0) @ Qb

pair = (-np.einsum('mi,mi->m', hF, hx)
        + np.einsum('mi,mi->m', hB, hy)
        + np.einsum('mij,mij->m', hSig, hz)
        + np.einsum('q,mi,mqi->m', wts * nodes, hUps, hr)).mean()

rhs = (-np.einsum('mi,ij,mj->m', hx, Q, hx).mean()
       - hx.mean(0) @ Qb @ hx.mean(0)
       - np.einsum('mi,ij,mj->m', hPi, Rinv, hPi).mean())

print(f"pairing (LHS) = {pair: .6f}")
print(f"identity (RHS)= {rhs: .6f}")
print(f"relative difference = {abs(pair-rhs)/abs(rhs):.2e}   (Monte-Carlo, M={M})")
print(f"beta_1 = lambda_min(Q) = {np.linalg.eigvalsh(Q)[0]:.4f};  bound satisfied:",
      pair <= -np.linalg.eigvalsh(Q)[0]*np.einsum('mi,mi->m', hx, hx).mean() + 1e-6)
